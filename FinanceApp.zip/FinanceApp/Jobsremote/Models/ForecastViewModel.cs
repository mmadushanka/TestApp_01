﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestAppAPI.Models
{
    public class ForecastViewModel
    {
        public float HoursOfSun { get; set; }
        public string Date { get; set; }
        public int DayPrecipitationProbability { get; set; } 
        public int DayThunderstormProbability { get; set; } 
        public int DayRainProbability { get; set; } 
        public int DaySnowProbability { get; set; } 
        public int DayIceProbability { get; set; } 
        public float DayHoursOfPrecipitation { get; set; }  
        public float DayHoursOfRain { get; set; } 
        public double DayWindSpeedValue { get; set; }
        public double DayRainValue { get; set; }
        public double DaySnowValue { get; set; }

        public int NightPrecipitationProbability { get; set; } 
        public int NightThunderstormProbability { get; set; } 
        public int NightRainProbability { get; set; }  
        public int NightSnowProbability { get; set; } 
        public int NightIceProbability { get; set; }
        public float NightHoursOfPrecipitation { get; set; }
        public float NightHoursOfRain { get; set; }
        public string SunSet { get; set; }
        public string MoonSet { get; set; }
        public double TemperatureMinimum { get; set; }
        public double TemperatureMaximum { get; set; }

    }
}
