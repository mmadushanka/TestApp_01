﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Domain.Models;
using N.Services.Contracts;
using N.Services.Implementations;
using System.Net.Http;
using Newtonsoft.Json;
using N.Data.Entities;

namespace TestAppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehicleMakeController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly IMapper mapper;
        private readonly IVehicleMakeService _vehicleMakeService;
        public VehicleMakeController(ILogger<VehicleMakeController> logger, IMapper mapper, IVehicleMakeService vehicleMakeService)
        {
            _logger = logger;
            this._vehicleMakeService = vehicleMakeService;
            this.mapper = mapper;
        }

        [HttpGet]
        public async Task<ActionResult<List<VehicleMakeModel>>> Get()
        {
            try
            {
                var vehicleMakes = await _vehicleMakeService.Get();
                if (vehicleMakes == null) return NotFound();

                var makes = mapper.Map<List<VehicleMakeModel>>(vehicleMakes);
                return Ok(makes);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in retrieving the data: {0} ", ex.Message);
                string logMessage = $"Error in retrieving the data at { DateTime.UtcNow.ToLongTimeString()} : ";
                _logger.LogInformation(logMessage);
                return null;
            }
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<VehicleMakeModel>> Get(int id)
        {
            try
            {
                var obj = await _vehicleMakeService.GetById(id);
                if (obj == null) return NotFound();

                var result = mapper.Map<VehicleMakeModel>(obj);

                return Ok(result); // Before asp.net core 2.1
                //return result; 
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in retrieving the data with id  {0} ,{1} ", id, ex.Message);
                string logMessage = $"Error in retrieving the data at { DateTime.UtcNow.ToLongTimeString()} : ";
                _logger.LogInformation(logMessage);

                return BadRequest("Cannot retrieve the item with id : ");
            }
        }

        [HttpPost]
        public async Task<ActionResult<VehicleMakeModel>> Post([FromBody] VehicleMakeModel model)
        {
            try
            {
                var make = mapper.Map<VehicleMake>(model);
                var obj = await _vehicleMakeService.Insert(make);
                //TODO - Need to check for existing objects

                var result = mapper.Map<VehicleMakeModel>(obj);

                return Ok(result);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in retrieving the data,  {0} ", ex.Message);
                string logMessage = $"Error in retrieving the data at { DateTime.UtcNow.ToLongTimeString()} : ";
                _logger.LogInformation(logMessage);

                return BadRequest("Cannot insert the item : ");
            }
        }

        //// DELETE api/<MController>/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
    }
}
