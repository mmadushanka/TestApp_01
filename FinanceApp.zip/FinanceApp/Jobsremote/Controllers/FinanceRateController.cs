﻿using AutoMapper;
using Domain.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using N.Data.Entities;
using N.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TestAppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FinanceRateController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly IMapper mapper;
        private readonly IFinanceRateService _financeRateService;
        public FinanceRateController(ILogger<FinanceRateController> logger, IMapper mapper, IFinanceRateService financeRateService)
        {
            _logger = logger;
            this._financeRateService = financeRateService;
            this.mapper = mapper;
        }

        [HttpGet("")]
        public async Task<ActionResult<List<FinanceRateModel>>> Get()
        {
            try
            {
                var vehicleMakes = await _financeRateService.Get();
                if (vehicleMakes == null) return NotFound();

                var makes = mapper.Map<List<FinanceRateModel>>(vehicleMakes);
                return Ok(makes);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in retrieving the data: {0} ", ex.Message);
                string logMessage = $"Error in retrieving the data at { DateTime.UtcNow.ToLongTimeString()} : ";
                _logger.LogInformation(logMessage);
                return null;
            }
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<FinanceRateModel>> Get(int id)
        {
            try
            {
                var obj = await _financeRateService.GetById(id);
                if (obj == null) return NotFound();

                var result = mapper.Map<FinanceTypeModel>(obj);

                return Ok(result); // Before asp.net core 2.1
                //return result; 
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in retrieving the data with id  {0} ,{1} ", id, ex.Message);
                string logMessage = $"Error in retrieving the data at { DateTime.UtcNow.ToLongTimeString()} : ";
                _logger.LogInformation(logMessage);

                return BadRequest("Cannot retrieve the item with id : ");
            }
        }

        [HttpPost]
        public async Task<ActionResult<FinanceRateModel>> Post([FromBody] FinanceRateModel model)
        {
            try
            {
                var make = mapper.Map<VehicleFinanceRateRange>(model);
                var obj = await _financeRateService.Insert(make);
                //TODO - Need to check for existing objects

                var result = mapper.Map<FinanceRateModel>(obj);

                return Ok(result);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in retrieving the data,  {0} ", ex.Message);
                string logMessage = $"Error in retrieving the data at { DateTime.UtcNow.ToLongTimeString()} : ";
                _logger.LogInformation(logMessage);

                return BadRequest("Cannot insert the item : ");
            }
        }

        // PUT api/<MController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<MController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
