﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using N.Data.Entities;

namespace TestAppAPI.Mapper
{
    public class AutoMapping : Profile
    {
        public AutoMapping()
        {
            // means you want to map from User to UserDTO
            CreateMapping();
        }

        private void CreateMapping()
        {
            CreateMap<Domain.Models.VehicleMakeModel, VehicleMake>().ReverseMap();
               //.ForMember( p => p.VehicleTypes, x => x.MapFrom(o => o.VehicleTypes)).ReverseMap();
            CreateMap<Domain.Models.VehicleTypeModel, VehicleType>().ReverseMap();
            CreateMap<Domain.Models.VehicleFinanceTypeModel, VehicleFinanceType>().ReverseMap();
            CreateMap<Domain.Models.FinanceRateModel, VehicleFinanceRateRange>().ReverseMap();
        }
    }
}
