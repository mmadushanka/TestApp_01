﻿using System;
using System.Collections.Generic;
using System.Text;

namespace N.Utilities.Helpers.Interfaces
{
    public interface IJsonAttribute
    {
        object TryConvert(string modelvalue, Type targetType, out bool success);
    }
}
