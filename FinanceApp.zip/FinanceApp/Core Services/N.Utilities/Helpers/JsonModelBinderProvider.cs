﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using N.Utilities.Helpers.Implementations;
using N.Utilities.Helpers.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace N.Utilities.Helpers
{
    public class JsonModelBinderProvider : IModelBinderProvider
    {
        public IModelBinder GetBinder(ModelBinderProviderContext context)
        {
            if (context == null) throw new ArgumentNullException(nameof(context));
            if(context.Metadata.IsComplexType)
            {
                var propName = context.Metadata.PropertyName;
                var propInfor = context.Metadata.ContainerType?.GetProperty(propName);
                if(propName == null || propInfor == null)
                {
                    return null;
                }

                var attribute = propInfor.GetCustomAttributes(typeof(FromJsonAttribute), false).FirstOrDefault();
                if (attribute != null)
                    return new JsonModelBinder(context.Metadata.ModelType, attribute as IJsonAttribute);
            }
            return null;
        }
    }
}
