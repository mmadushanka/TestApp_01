﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace N.Utilities.Operations.Interfaces
{
    public interface IEmailSender
    {
        Task SendEmailAsync(string email, string subject, string htmlMessage);
        //Task SendEmail(string MailTo, string MailSubject);
    }
}
