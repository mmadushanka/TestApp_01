﻿using N.Data.Context;
using N.Data.Entities;
using N.Data.Repositories.Interfaces;
using N.Data.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N.Data.Repositories
{
    public class FinanceTypeRepository : Repository<NTDbContext, FinanceType>, IFinanceTypeRepository
    {
        public readonly NTDbContext dbContext;
        public FinanceTypeRepository(NTDbContext _dbContext) : base(_dbContext)
        {
            dbContext = _dbContext;
        }
    }
}
