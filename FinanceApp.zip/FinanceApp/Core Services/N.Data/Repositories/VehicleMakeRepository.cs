﻿using N.Data.Context;
using N.Data.Entities;
using N.Data.Repositories.Interfaces;
using N.Data.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N.Data.Repositories
{
    public class VehicleMakeRepository : Repository<NTDbContext, VehicleMake>, IVehicleMakeRepository
    {
        public readonly NTDbContext dbContext;
        public VehicleMakeRepository(NTDbContext _dbContext) : base(_dbContext)
        {
            dbContext = _dbContext;
        }
    }
}
