﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace N.Data.UnitOfWork
{
    public class RepositoryCommon<CContext, T> : IRepositoryCommon<CContext, T> where T : class where CContext : DbContext, new()
    {
        private CContext _dbContext;
        private DbSet<T> _dbSet;

        public RepositoryCommon(CContext dbContext)
        {
            this._dbContext = dbContext;
            this._dbSet = dbContext.Set<T>();
        }

        /// <summary>
        /// Gets the specified filter.
        /// </summary>
        /// <param name="filter">The filter.</param>
        /// <param name="orderBy">The order by.</param>
        /// <param name="includeProperties">The include properties. not implemented since lazy loading not yet support ef core</param>
        /// <returns>IQueryable&lt;TEntity&gt;.</returns>
        public async Task<IQueryable<T>> Get(
            Expression<Func<T, bool>> filter = null,
            Func<IQueryable<T>, IOrderedQueryable<T>> orderBy = null,
            string includeProperties = "")
        {
            IQueryable<T> query = _dbSet;

            if (filter != null)
                query = await Task.Run(() => query.Where(filter));

            if (!string.IsNullOrEmpty(includeProperties))
            {
                foreach (var includeProperty in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProperty);
                }
            }

            return (orderBy != null) ? orderBy(query) : query;
        }

        public async Task<IQueryable<T>> FindBy(System.Linq.Expressions.Expression<Func<T, bool>> predicate, string includeProperties = "")
        {
            IQueryable<T> query = _dbSet;

            if (!string.IsNullOrEmpty(includeProperties))
            {
                foreach (var includeProperty in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProperty);
                }
            }

            //query = query.Where(predicate);
            query = await Task.Run(() => query.Where(predicate));
            return query;
        }

        ///// <summary>
        ///// Gets the by identifier.
        ///// </summary>
        ///// <param name="id">The identifier.</param>
        ///// <returns>TEntity.</returns>
        //public async Task<T> GetById(Int64 id, string includeProperties = "")
        //{
        //    IQueryable<T> query = _dbSet;

        //    foreach (var includeProperty in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
        //    {
        //        query = query.Include(includeProperty);
        //    }

        //    return await query.SingleOrDefaultAsync(i => i.Id == id);
        //}

        /// <summary>
        /// Inserts the specified entity.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <exception cref="System.ArgumentNullException">entity</exception>
        public async Task<T> Insert(T entity)
        {
            if (entity == null)
                throw new ArgumentNullException("entity");

            await this._dbSet.AddAsync(entity);
            await this._dbContext.SaveChangesAsync();

            return entity;
        }

        /// <summary>
        /// Deletes the specified entity to delete.
        /// </summary>
        /// <param name="entityToDelete">The entity to delete.</param>
        /// <exception cref="System.ArgumentNullException">entity</exception>
        public async Task Delete(T entityToDelete)
        {
            if (entityToDelete == null)
                throw new ArgumentNullException("entity");

            this._dbSet.Remove(entityToDelete);
            await this._dbContext.SaveChangesAsync();
        }

        /// <summary>
        /// Updates the specified entity to update.
        /// </summary>
        /// <param name="entityToUpdate">The entity to update.</param>
        /// <exception cref="System.ArgumentNullException">entity</exception>
        public async Task<T> Update(T entityToUpdate)
        {
            if (entityToUpdate == null)
                throw new ArgumentNullException("entity");

            this._dbSet.Update(entityToUpdate);
            await this._dbContext.SaveChangesAsync();

            return entityToUpdate;
        }

        //public Task<T> GetById(long id, string includeProperties = "")
        //{
        //    throw new NotImplementedException();
        //}
    }
}
