﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N.Data.Entities
{
    public class VehicleMake : BaseEntity
    {
        public string Name { get; set; }
        public virtual ICollection<MakeVehicleType> VehicleTypes { get; set; }
    }
}

