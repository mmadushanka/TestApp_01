﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N.Data.Entities
{
    public class VehicleFinanceRateRange : BaseEntity
    {
        public string Range { get; set; } // 0-3 months, 3-6 months
        public double Rate { get; set; } // 5.0, 6.0
        public virtual ICollection<VehicleFinanceType> VehicleFinanceTypes { get; set; }
    }
}
