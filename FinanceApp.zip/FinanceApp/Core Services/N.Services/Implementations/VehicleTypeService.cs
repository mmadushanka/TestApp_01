﻿using N.Data.Entities;
using N.Data.Repositories.Interfaces;
using N.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace N.Services.Implementations
{
    public class VehicleTypeService : IVehicleTypeService
    {
        private readonly IVehicleTypeRepository _vehicleTypeRepository;
        public VehicleTypeService(IVehicleTypeRepository vehicleTypeRepository)
        {
            this._vehicleTypeRepository = vehicleTypeRepository;
        }

        /// <summary>
        /// Gets the specified filter.
        /// </summary>
        /// <param name="filter">The filter.</param>
        /// <param name="orderBy">The order by.</param>
        /// <param name="includeProperties">The include properties. not implemented since lazy loading not yet support ef core</param>
        /// <returns>IQueryable&lt;TEntity&gt;.</returns>
        public async Task<IQueryable<VehicleType>> Get(
            Expression<Func<VehicleType, bool>> filter = null,
            Func<IQueryable<VehicleType>, IOrderedQueryable<VehicleType>> orderBy = null,
            string includeProperties = "")
        {
            var clients = await _vehicleTypeRepository.Get(filter, orderBy, includeProperties);
            return clients;
        }

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>TEntity.</returns>
        public async Task<VehicleType> GetById(Int64 id, string includeProperties = "")
        {
            var client = await _vehicleTypeRepository.GetById(id, includeProperties);
            return client;
        }

        /// <summary>
        /// Inserts the vType.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <exception cref="System.ArgumentNullException">entity</exception>
        public async Task<VehicleType> Insert(VehicleType entity)
        {
            var client = await _vehicleTypeRepository.Insert(entity);
            return client;
        }

        /// <summary>
        /// Deletes the vType.
        /// </summary>
        /// <param name="entityToDelete">The entity to delete.</param>
        /// <exception cref="System.ArgumentNullException">entity</exception>
        public async Task Delete(VehicleType entity)
        {
            await _vehicleTypeRepository.Delete(entity);
        }

        /// <summary>
        /// Updates the vType.
        /// </summary>
        /// <param name="entityToUpdate">The entity to update.</param>
        /// <exception cref="System.ArgumentNullException">entity</exception>
        public async Task<VehicleType> Update(VehicleType entityToUpdate)
        {
            var client = await _vehicleTypeRepository.Update(entityToUpdate);
            return client;
        }
    }
}
