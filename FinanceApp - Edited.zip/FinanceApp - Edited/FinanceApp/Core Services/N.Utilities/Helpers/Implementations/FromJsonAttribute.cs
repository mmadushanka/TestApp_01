﻿using N.Utilities.Helpers.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace N.Utilities.Helpers.Implementations
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public class FromJsonAttribute : Attribute, IJsonAttribute
    {
        public object TryConvert(string modelvalue, Type targetType, out bool success)
        {
            var value = JsonConvert.DeserializeObject(modelvalue, targetType);
            success = value != null;
            return value;
            //throw new NotImplementedException();
        }
    }
}
