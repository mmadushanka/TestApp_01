﻿using System;

namespace N.Utilities
{
    public sealed class Class1
    {
        private static Class1 _class1 = null;
        public static Class1 GetIntance
        {
            get
            { 
                if (_class1 != null)
                {
                    _class1 = new Class1();
                }
                return _class1;
            }
        }

    }
}
