﻿namespace N.Utilities.Common.Constants
{
    public enum UserType
    {
        Admin,
        NormalUser,
        Client,
        Tenant,
        PropertyManager
    }

    public enum EventType
    {
        MaintenanceEvent = 1,
        VacancyEvent,
        GeneralEvent
    }

    public enum EventStatus
    {
        Open = 1, Closed
    }

    public enum ClientEventStatus
    {
        Active =1, DeActive
    }
    public enum ActionStatus
    {
        Open = 1, Closed
    }

    public enum ActionPriority
    {
        Low = 1, Medium, High, Critical
    }
    
    public enum PropertyOtherFeeActionType
    {
        PropertyOtherFeeTask = 1,
        PropertyTenantIncomeTask,
        ProperrtClientIncomeTask

    }

    public enum EventPriority
    {
        Low = 1, Medium, High, Critical
    }

    public enum PropertyType
    {
        Houses = 1,
        Apartments,
        Lands,
        Buildings,
        Commercial
    }

    public enum PropertyState
    {
        Vacant = 1, Occupied
    }

    public enum PropertyStatus //Database manupulation purpose
    {
        Active = 1, DeActive,
        Delete
    }

    public enum FeeRecurrenceFrequency
    {
        Daily = 1, Weekly, Monthly, BiMonthly, Quarterly, Yearly
    }

    public enum FeeType
    {
        PropertyOtherFee = 1,//expense
        TenantIncome,
        ClientIncome,
    }

    public enum RecurrenceFrequency
    {
        Daily =1 , Weekly, Monthly, BiMonthly, Quarterly, Yearly
    }

    public enum PropertyManagerStatus
    {
        Active = 1, Deactive = 0
    }

    public enum PropertyClientStatus
    {
        Active = 1, Deactive = 0
    }

    public enum PropertyOtherFeeStatus
    {
        Active = 1, Deactive = 0
    }

    public enum ManagerFeeType
    {
        Fixed = 1, Percentage = 0
    }

    public enum TransactionStatus //Database manupulation purpose
    {
        Pending = 1, Closed,
        Cancelled
    }

    public enum TransactionCategory
    {
        PropertyIncome = 1,
        ClientIncome,
        GeneralIncome,
        PropertyExpense,
        ClientExpense,
        GeneralExpense
    }

    public enum TransactionType
    {
        Credit = 1,
        Debit
    }

    public enum ReminderStatus
    {
        Active = 1,
        DeActive
    }

    public enum ReminderType
    {
        ActionReminder = 1,
        ClientReminder,
        PropertyRemimder,
        PropertyMangerReminder
    }
}
