﻿using N.Data.Entities;
using N.Data.Repositories.Interfaces;
using N.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace N.Services.Implementations
{
    public class FinanceTypeService : IFinanceTypeService
    {
        private readonly IFinanceTypeRepository _financeTypeRepository;
        public FinanceTypeService(IFinanceTypeRepository financeTypeRepository)
        {
            this._financeTypeRepository = financeTypeRepository;
        }


        /// <summary>
        /// Gets the specified filter.
        /// </summary>
        /// <param name="filter">The filter.</param>
        /// <param name="orderBy">The order by.</param>
        /// <param name="includeProperties">The include properties. not implemented since lazy loading not yet support ef core</param>
        /// <returns>IQueryable&lt;TEntity&gt;.</returns>
        public async Task<IQueryable<FinanceType>> Get(
            Expression<Func<FinanceType, bool>> filter = null,
            Func<IQueryable<FinanceType>, IOrderedQueryable<FinanceType>> orderBy = null,
            string includeProperties = "")
        {
            var clients = await _financeTypeRepository.Get(filter, orderBy, includeProperties);
            return clients;
        }

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>TEntity.</returns>
        public async Task<FinanceType> GetById(Int64 id, string includeProperties = "")
        {
            var client = await _financeTypeRepository.GetById(id, includeProperties);
            return client;
        }

        /// <summary>
        /// Inserts the vMake.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <exception cref="System.ArgumentNullException">entity</exception>
        public async Task<FinanceType> Insert(FinanceType entity)
        {
            var client = await _financeTypeRepository.Insert(entity);
            return client;
        }

        /// <summary>
        /// Deletes the vMake.
        /// </summary>
        /// <param name="entityToDelete">The entity to delete.</param>
        /// <exception cref="System.ArgumentNullException">entity</exception>
        public async Task Delete(FinanceType entity)
        {
            await _financeTypeRepository.Delete(entity);
        }

        /// <summary>
        /// Updates the vMake.
        /// </summary>
        /// <param name="entityToUpdate">The entity to update.</param>
        /// <exception cref="System.ArgumentNullException">entity</exception>
        public async Task<FinanceType> Update(FinanceType entityToUpdate)
        {
            var client = await _financeTypeRepository.Update(entityToUpdate);
            return client;
        }
    }
}
