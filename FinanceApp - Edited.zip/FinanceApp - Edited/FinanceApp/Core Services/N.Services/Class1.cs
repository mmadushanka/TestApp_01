﻿using System;

namespace N.Services
{
    public class Class1
    {
    }
}
