﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using N.Utilities.Common.Constants;

namespace N.Data.Entities
{
    public class ApplicationUser : IdentityUser
    {
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string WebSite { get; set; }
        public string MobileNumber { get; set; }
        public string Fax { get; set; }
        public string Address { get; set; }
        public string Location { get; set; }
        public string Zip { get; set; }
        public string City { get; set; }
        public string Unit { get; set; }
        public int? StateId { get; set; }
        public string UserStateTag { get; set; }
        public int? CountryId { get; set; }
       // public Country Country { get; set; }
        public string UserCountryTag { get; set; }
        public bool IsACompany { get; set; }
        //public int? CompanyId { get; set; }
        //public Company Company { get; set; }
        public string ProfileImageUrl { get; set; }
        public string Description { get; set; }
        public int UserTypeId { get; set; }
        public UserType UserType { get; set; }
        public bool IsActive { get; set; }
        public string BankAccountNumber { get; set; }
        public string BankName { get; set; }
        public string BankBranchCode { get; set; }
        public string BankSwiftCode { get; set; }
        public string BranchAddress { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public DateTime LastUpdatedDateTime { get; set; }
        public string CreatedBy { get; set; }
        public string LastUpdatedBy { get; set; }
        public bool IsTermAgreed { get; set; }
        public int? UserSubscriptionId { get; set; }
        //public int UserSubscriptionTrialId { get; set; }

        //public virtual UserSubscription UserSubscription { get; set; }
        ////public virtual UserSubscriptionTrial UserSubscriptionTrial { get; set; }
        //public virtual ICollection<Flag> Flags { get; set; } // flags done by other users to this user.
        //public virtual ICollection<Flag> UserFlags { get; set; } // flags done by this user
        //public virtual ICollection<Flag> UserUnFlags { get; set; } // flags removed by this user
    }
}
