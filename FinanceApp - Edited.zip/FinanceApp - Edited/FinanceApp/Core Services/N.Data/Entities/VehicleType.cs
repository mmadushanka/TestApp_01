﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N.Data.Entities
{
    public class VehicleType : BaseEntity
    {
        public string Type { get; set; }
        public virtual ICollection<MakeVehicleType> MakeVehicleTypes { get; set; }
        public virtual ICollection<VehicleFinanceType> VehicleFinanceTypes { get; set; }
    }
}
