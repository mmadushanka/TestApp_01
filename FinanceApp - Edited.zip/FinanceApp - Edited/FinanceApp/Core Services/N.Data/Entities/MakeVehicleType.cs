﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N.Data.Entities
{
    public class MakeVehicleType :Base
    {
        public int MakeId { get; set; } // Audi, BMW
        public int VehicleTypeId { get; set; } // Car, Van

        public virtual VehicleMake Make { get; set; }
        public virtual VehicleType VehicleType { get; set; }
    }
}
