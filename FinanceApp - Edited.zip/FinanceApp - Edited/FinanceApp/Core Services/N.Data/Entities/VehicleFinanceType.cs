﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N.Data.Entities
{
    public class VehicleFinanceType :Base
    {
        public int VehicleTypeId { get; set; }
        public int FinanceTypeId { get; set; }
        public int FinanceRateRangeId { get; set; }

        public virtual FinanceType FinanceType { get; set; }
        public virtual VehicleType VehicleType { get; set; }
        public virtual VehicleFinanceRateRange VehicleFinanceRateRange { get; set; }
    }
}
