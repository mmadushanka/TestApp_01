﻿using System;

namespace N.Data
{
    public class Class1
    {
    }
}
