﻿using N.Data.Context;
using N.Data.Entities;
using N.Data.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N.Data.Repositories.Interfaces
{
    public interface IVehicleTypeRepository : IRepository<NTDbContext, VehicleType>
    {
    }
}
