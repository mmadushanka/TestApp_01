﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using N.Data.Entities;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace N.Data.Context
{
    public class NTDbContext : IdentityDbContext<ApplicationUser>
    {
        public NTDbContext(DbContextOptions<NTDbContext> options):base(options)
        {

        }
        public NTDbContext()
        {

        }

        public DbSet<VehicleMake> VehicleMakes { get; set; }
        public DbSet<VehicleType> VehicleTypes { get; set; }
        public DbSet<FinanceType> FinanceTypes { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<MakeVehicleType>().HasKey(p => new { p.MakeId, p.VehicleTypeId });
            modelBuilder.Entity<MakeVehicleType>().HasOne(p => p.Make).WithMany(b => b.VehicleTypes).HasForeignKey(f => f.MakeId);
            modelBuilder.Entity<MakeVehicleType>().HasOne(p => p.VehicleType).WithMany(b => b.MakeVehicleTypes).HasForeignKey(f => f.VehicleTypeId);
            modelBuilder.Entity<VehicleFinanceType>().HasOne(p => p.VehicleType).WithMany(b => b.VehicleFinanceTypes).HasForeignKey(f => f.VehicleTypeId);
            modelBuilder.Entity<VehicleFinanceType>().HasOne(p => p.FinanceType).WithMany(b => b.VehicleFinanceTypes).HasForeignKey(f => f.FinanceTypeId);
            modelBuilder.Entity<VehicleFinanceType>().HasOne(p => p.VehicleFinanceRateRange).WithMany(b => b.VehicleFinanceTypes).HasForeignKey(f => f.FinanceRateRangeId);
        }
    }
}
