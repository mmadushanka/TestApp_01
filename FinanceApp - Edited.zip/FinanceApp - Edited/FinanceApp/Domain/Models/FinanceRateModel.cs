﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Models
{
    public class FinanceRateModel
    {
        public int Id { get; set; }
        public string Range { get; set; } // 0-3 months, 3-6 months
        public double Rate { get; set; } // 5.0, 6.0
        //public List<VehicleFinanceTypeModel> VehicleFinanceTypes { get; set; }
    }
}
