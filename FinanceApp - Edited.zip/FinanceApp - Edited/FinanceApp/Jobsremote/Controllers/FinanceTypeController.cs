﻿using AutoMapper;
using Domain.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using N.Data.Entities;
using N.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TestAppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FinanceTypeController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly IMapper mapper;
        private readonly IFinanceTypeService _financeTypeService;
        public FinanceTypeController(ILogger<FinanceTypeController> logger, IMapper mapper, IFinanceTypeService financeTypeService)
        {
            _logger = logger;
            this._financeTypeService = financeTypeService;
            this.mapper = mapper;
        }

        [HttpGet("")]
        public async Task<ActionResult<List<FinanceTypeModel>>> Get()
        {
            try
            {
                var vehicleMakes = await _financeTypeService.Get();
                if (vehicleMakes == null) return NotFound();

                var makes = mapper.Map<List<FinanceTypeModel>>(vehicleMakes);
                return Ok(makes);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in retrieving the data: {0} ", ex.Message);
                string logMessage = $"Error in retrieving the data at { DateTime.UtcNow.ToLongTimeString()} : ";
                _logger.LogInformation(logMessage);
                return null;
            }
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<FinanceTypeModel>> Get(int id)
        {
            try
            {
                var obj = await _financeTypeService.GetById(id);
                if (obj == null) return NotFound();

                var result = mapper.Map<FinanceTypeModel>(obj);

                return Ok(result); // Before asp.net core 2.1
                //return result; 
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in retrieving the data with id  {0} ,{1} ", id, ex.Message);
                string logMessage = $"Error in retrieving the data at { DateTime.UtcNow.ToLongTimeString()} : ";
                _logger.LogInformation(logMessage);

                return BadRequest("Cannot retrieve the item with id : ");
            }
        }

        [HttpPost]
        public async Task<ActionResult<FinanceTypeModel>> Post([FromBody] FinanceTypeModel model)
        {
            try
            {
                var make = mapper.Map<FinanceType>(model);
                var obj = await _financeTypeService.Insert(make);
               //TODO - Need to check for existing objects

                var result = mapper.Map<FinanceTypeModel>(obj);

                return Ok(result);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in retrieving the data,  {0} ", ex.Message);
                string logMessage = $"Error in retrieving the data at { DateTime.UtcNow.ToLongTimeString()} : ";
                _logger.LogInformation(logMessage);

                return BadRequest("Cannot insert the item : ");
            }
        }

        // PUT api/<MController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<MController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
