using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TestAppAPI.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using N.Data.Context;
using N.Data.Repositories;
using N.Data.Repositories.Interfaces;
using N.Services.Contracts;
using N.Services.Implementations;
using AutoMapper;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Extensions.FileProviders;
using System.IO;
using Microsoft.AspNetCore.Http;
using N.Utilities.Helpers;
using Microsoft.AspNetCore.Mvc.Cors;
using Microsoft.OpenApi.Models;
//using Newtonsoft.Json.Serialization;

namespace TestAppAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            //services.AddDbContext<PaymentDetailContext>(optionns =>
            //optionns.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")), ServiceLifetime.Scoped);

            services.AddDbContext<NTDbContext>(options =>
              options.UseSqlServer(Configuration.GetConnectionString("TestDBConnection")), ServiceLifetime.Scoped);

            // services.AddControllers(options => options.AddGlobalLoggingRequestFilters())
            //.AddNewtonsoftJson(options =>
            //{
            //    options.SerializerSettings.ApplyCommonSettings();
            //});

            services.AddControllers().AddJsonOptions(options =>
           {
               options.JsonSerializerOptions.PropertyNamingPolicy = null;
               options.JsonSerializerOptions.DictionaryKeyPolicy = null;
           });
            //     .AddNewtonsoftJson(options =>
            //{
            //    options.SerializerSettings.ContractResolver = new DefaultContractResolver();
            //});

            services.AddSwaggerGen();
            //services.AddSwaggerGen(c =>
            //   {
            //       c.SwaggerDoc("v1", new OpenApiInfo { Title = "Test App API", Version = "v1" });
            //   }
            //    );


            services.Configure<FormOptions>(o =>
            {
                o.ValueLengthLimit = int.MaxValue;
                o.MultipartBodyLengthLimit = int.MaxValue;
                o.MemoryBufferThreshold = int.MaxValue;
            });

            // Not supported from .Net core 3.0 +
            //services.AddMvc().AddJsonOptions(options => options.SerializerSettings.ContractResolver = new DefaultContractResolver());

            //services.AddMvcCore().AddNewtonsoftJson();

            //services.AddMvc(properties =>
            //{
            //    properties.ModelBinderProviders.Insert(0, new JsonModelBinderProvider());
            //});

            services.AddAutoMapper(typeof(Startup));

           // services.AddTransient<IBidRepository, BidRepository>();
            services.AddTransient<IVehicleMakeRepository, VehicleMakeRepository>();
            services.AddTransient<IVehicleTypeRepository, VehicleTypeRepository>();
            services.AddTransient<IFinanceRateRepository, FinanceRateRepository>();
            services.AddTransient<IFinanceTypeRepository, FinanceTypeRepository>();

            services.AddTransient<IVehicleMakeService, VehicleMakeService>();
            services.AddTransient<IVehicleTypeService, VehicleTypeService>();
            services.AddTransient<IFinanceRateService, FinanceRateService>();
            services.AddTransient<IFinanceTypeService, FinanceTypeService>();

            var corsUrls = new List<string>() { "http://localhost:4200" };

            services.AddCors(o => o.AddPolicy("CorsPolicy", builder =>
            {
                builder
                  .AllowAnyMethod() //<--this allows preflight headers required for POST
                  .AllowAnyHeader() //<--accepts headers 
                  .AllowCredentials() //<--lets your app send auth credentials
                  .WithOrigins(corsUrls.ToArray()); //<--this is the important line
            }));

            //services.Configure<MvcOptions>(
            //    options => { options.Filters.Add(new CorsAuthorizationFilterFactory("CorsPolicy")); });
            //services.AddCors();
        }


        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            loggerFactory.AddFile("Logs/mylog-{Date}.txt");

            //app.UseSwagger();
            //app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "WebApi v1"));

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI();

            }

            app.UseHttpsRedirection();

            app.UseStaticFiles();
            //app.UseStaticFiles(new StaticFileOptions()
            //{
            //    FileProvider = new PhysicalFileProvider(Path.Combine(Directory.GetCurrentDirectory(), @"StaticFiles")),
            //    RequestPath = new PathString("/StaticFiles")
            //});

            app.UseRouting();

            app.UseCors("CorsPolicy");
            //app.UseCors(options => options.WithOrigins("http://localhost:4200").AllowAnyMethod().AllowAnyHeader());
            //app.UserCors();

            //app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });


        }
    }
}
